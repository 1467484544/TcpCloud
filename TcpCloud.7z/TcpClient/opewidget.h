#ifndef OPEWIDGET_H
#define OPEWIDGET_H

#include <QObject>
#include <QWidget>
#include<QListWidget>
#include<QStackedWidget>

#include"book.h"
#include"friend.h"

class OpeWidget : public QWidget
{
    Q_OBJECT
public:
    explicit OpeWidget(QWidget *parent = 0);

    static OpeWidget &getInstance();

    Friend *getFriend();

    Book* getBook();

signals:

private:
    QListWidget* m_pListW;//左边
    QStackedWidget *m_pSw;//右边

    Friend* m_pFriend;//好友
    Book* m_pbook;//文件操作






};

#endif // OPEWIDGET_H
