#include "online.h"
#include "ui_online.h"
#include<QDebug>
#include"tcpclient.h"

Online::Online(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Online)
{
    ui->setupUi(this);
}

Online::~Online()
{
    delete ui;
}

void Online::showUsr(PDU *pdu)
{
    if(pdu==NULL)
    {
        return;
    }

    //重新点击按钮清除
    ui->online_listWidget->clear();

    uint uiSize=pdu->uiMsgLen/32;
    char caTmp[32];
    for(int i=0;i<uiSize;i++)
    {
        memcpy(caTmp,(char*)(pdu->caMsg)+i*32,32);
        ui->online_listWidget->addItem(caTmp);
    }
}

void Online::on_addFriend_btn_clicked()
{
    QListWidgetItem* pItem=ui->online_listWidget->currentItem();
    QString strPerUsrName=pItem->text();
    QString strLoginName=TcpClient::getInstance().LoginName();
    PDU* pdu=mkPDU(0);
    pdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_REQUEST;
    memcpy(pdu->caData,strPerUsrName.toStdString().c_str(),strPerUsrName.size());
    memcpy(pdu->caData+32,strLoginName.toStdString().c_str(),strLoginName.size());
    TcpClient::getInstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
    free(pdu);
    pdu=NULL;
}
