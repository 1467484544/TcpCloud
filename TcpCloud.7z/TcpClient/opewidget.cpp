#include "opewidget.h"
#include"tcpclient.h"


OpeWidget::OpeWidget(QWidget *parent) : QWidget(parent)
{
    QString strLoginName=TcpClient::getInstance().LoginName();
    this->setWindowTitle(strLoginName);
    m_pListW=new QListWidget(this);
    m_pListW->addItem("好友");
    m_pListW->addItem("文件管理");

    m_pFriend=new Friend;
    m_pbook=new Book;

    m_pSw=new QStackedWidget;
    m_pSw->addWidget(m_pFriend);
    m_pSw->addWidget(m_pbook);

    QHBoxLayout *pMain=new QHBoxLayout;
    pMain->addWidget(m_pListW);
    pMain->addWidget(m_pSw);

    setLayout(pMain);

    connect(m_pListW,SIGNAL(currentRowChanged(int)),m_pSw,SLOT(setCurrentIndex(int)));

}

OpeWidget &OpeWidget::getInstance()
{
    static OpeWidget instance;
    return instance;
}

Friend *OpeWidget::getFriend()
{
    return m_pFriend;
}

Book *OpeWidget::getBook()
{
    return m_pbook;
}
