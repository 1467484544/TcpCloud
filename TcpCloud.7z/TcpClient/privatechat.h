#ifndef PRIVATECHAT_H
#define PRIVATECHAT_H

#include <QWidget>
#include"protocol.h"

namespace Ui {
class PrivateChat;
}

class PrivateChat : public QWidget
{
    Q_OBJECT

public:
    explicit PrivateChat(QWidget *parent = nullptr);
    ~PrivateChat();

    //设置聊天对象的名字
    void setChatName(QString strName);

    //单例模式
    static PrivateChat &getInstance();

    void updateMsg(const PDU* pdu);

private slots:
    void on_sendMsg_pushButton_clicked();

private:
    Ui::PrivateChat *ui;

    QString m_strLoginName;

    QString m_strChatName;
};

#endif // PRIVATECHAT_H
