#include"protocol.h"

PDU *mkPDU(uint uiMsgLen)
{
    uint uiPDULen=sizeof(PDU)+uiMsgLen;
    PDU* pdu=(PDU*)malloc(uiPDULen);
    if(pdu==NULL)
    {
        exit(EXIT_FAILURE);
    }
    memset(pdu,0,uiPDULen);//将pdu指针所指向的长度为uiPDULen字节的内存区域全部清零
    pdu->uiPDULen=uiPDULen;
    pdu->uiMsgLen=uiMsgLen;
    return pdu;
}
