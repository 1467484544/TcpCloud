#include "tcpclient.h"
#include <QApplication>

//#include"opewidget.h"
//#include"online.h"
//#include"friend.h"
#include"sharefile.h".h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
//    TcpClient w;
//    w.show();
    TcpClient::getInstance().show();
//    OpeWidget w;
//    w.show();
//    Online w;
//    w.show();
//    Friend w;
//    w.show();
//        ShareFile w;
//        w.show();


    return a.exec();
}
