#ifndef MYTCPSERVER_H
#define MYTCPSERVER_H
#include<QTcpServer>
#include<QList>
#include"mytcpsocket.h"


class MyTcpServer : public QTcpServer
{
    //写下这个宏后才支持信号槽
    Q_OBJECT
public:
    MyTcpServer();

    static MyTcpServer &getInstance();

    //重写，当有新的客户端连接时自动调用此函数
    void incomingConnection(qintptr socketDescriptor);

    void resend(const char * pername,PDU*pdu);

public slots:
    void deleteSocket(MyTcpSocket* mysocket);

private:
    QList<MyTcpSocket*> m_tcpSocketList;

};

#endif // MYTCPSERVER_H
