#include "mytcpsocket.h"
#include"mytcpserver.h"

#include<QDebug>
#include<QDir>
#include<QFileInfoList>
#include<QFile>


MyTcpSocket::MyTcpSocket()
{
    connect(this,SIGNAL(readyRead()),this,SLOT(recvMsg()));

    connect(this,SIGNAL(disconnected()),this,SLOT(clientOffline()));

    m_bUpload=false;

    m_pTimer=new QTimer;

    connect(m_pTimer,SIGNAL(timeout()),this,SLOT(sendFileToClient()));
}

QString MyTcpSocket::getName()
{
    return m_strName;
}

void MyTcpSocket::copyDir(QString strSrcDir, QString strDestDir)
{
    QDir dir;
    dir.mkdir(strDestDir);

    dir.setPath(strSrcDir);
    QFileInfoList fileInfoList=dir.entryInfoList();

    QString srcTmp;
    QString destTmp;

    for(int i=0;i<fileInfoList.size();i++)
    {
        if(fileInfoList[i].isFile())
        {
            qDebug()<<"fileName:"<<fileInfoList[i].fileName();
            srcTmp=strSrcDir+'/'+fileInfoList[i].fileName();
            destTmp=strDestDir+'/'+fileInfoList[i].fileName();
            QFile::copy(srcTmp,destTmp);
        }else if(fileInfoList[i].isDir())
        {
            if(fileInfoList[i].fileName()==QString(".")||fileInfoList[i].fileName()==QString(".."))
            {
                continue;
            }
            srcTmp=strSrcDir+'/'+fileInfoList[i].fileName();
            destTmp=strDestDir+'/'+fileInfoList[i].fileName();
            copyDir(srcTmp,destTmp);
        }
    }
}

void MyTcpSocket::recvMsg()
{
    if(!m_bUpload)
    {
        //qDebug()<<this->bytesAvailable();//获得数据的字节大小

        uint uiPDULen=0;//先定义一个uiPDULen用来存收到的总的消息的总大小
        this->read((char*)&uiPDULen,sizeof(uint));//然后先读一个uint大小的数据量，存到&uiPDULen中
        uint uiMsgLen=uiPDULen-sizeof(PDU);//再定义一个uiMsgLen来计算发送的消息内容的大小，为总长度-PDU的大小
        PDU* pdu=mkPDU(uiMsgLen);//创建一个大小为uiMsgLen的pdu，实际大小为PDU的大小+uiMsgLen的大小
        this->read((char*)pdu+sizeof(uint),uiPDULen-sizeof(uint));//最后读取uiMsgType,caData,uiMsgLen,caMsg等等

        //然后判断消息类型
        switch(pdu->uiMsgType)
        {
        case ENUM_MSG_TYPE_REGIST_REQUEST://注册请求消息类型
        {
            char caName[32]={'\0'};
            char caPwd[32]={'\0'};
            strncpy(caName,pdu->caData,32);
            strncpy(caPwd,pdu->caData+32,32);
            bool ret=OpeDB::getInstance().handleRegist(caName,caPwd);//将注册请求传到数据库里面
            PDU *respdu=mkPDU(0);
            respdu->uiMsgType=ENUM_MSG_TYPE_REGIST_RESPOND;
            if(ret)
            {
                strcpy(respdu->caData,REGIST_OK);
                QDir dir;
                //创建注册用户的文件夹的结果 ture/false
                qDebug()<<"create dir:"<<dir.mkdir(QString("./%1").arg(caName));
            }else
            {
                strcpy(respdu->caData,REGIST_FAILED);
            }
            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_LOGIN_REQUEST://登录请求消息类型
        {
            char caName[32]={'\0'};
            char caPwd[32]={'\0'};
            strncpy(caName,pdu->caData,32);
            strncpy(caPwd,pdu->caData+32,32);
            bool ret=OpeDB::getInstance().handleLogin(caName,caPwd);
            PDU *respdu=mkPDU(0);
            respdu->uiMsgType=ENUM_MSG_TYPE_LOGIN_RESPOND;
            if(ret)
            {
                strcpy(respdu->caData,LOGIN_OK);
                m_strName=caName;
            }else
            {
                strcpy(respdu->caData,LOGIN_FAILED);
            }
            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_ALL_ONLINE_REQUEST://查看所有在线用户请求
        {
            QStringList ret=OpeDB::getInstance().handleAllOnline();
            uint uiMsgLen=ret.size()*32;//在线用户名字的个数*名字字节大小
            PDU *respdu=mkPDU(uiMsgLen);
            respdu->uiMsgType=ENUM_MSG_TYPE_ALL_ONLINE_RESPOND;
            for(int i=0;i<ret.size();i++)
            {
                memcpy((char*)(respdu->caMsg)+i*32,
                       ret.at(i).toStdString().c_str(),ret.at(i).size());
            }
            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_SEARCH_USR_REQUEST://搜索用户请求
        {
            int ret=OpeDB::getInstance().handleSearchUsr(pdu->caData);
            PDU* respdu=mkPDU(0);
            respdu->uiMsgType=ENUM_MSG_TYPE_SEARCH_USR_RESPOND;
            if(ret==-1)
            {
                strcpy(respdu->caData,SEARCH_USR_NO);
            }else if(ret==1)
            {
                strcpy(respdu->caData,SEARCH_USR_ONLINE);
            }else if(ret==0)
            {
                strcpy(respdu->caData,SEARCH_USR_OFFLINE);
            }
            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_ADD_FRIEND_REQUEST://添加好友请求
        {
            char caPername[32]={'\0'};
            char caName[32]={'\0'};
            strncpy(caPername,pdu->caData,32);
            strncpy(caName,pdu->caData+32,32);
            int ret=OpeDB::getInstance().handleAddFriend(caPername,caName);
            PDU* respdu=NULL;
            if(ret==-1)//未知错误
            {
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_RESPOND;
                strcpy(respdu->caData,UNKNOW_ERROR);
                write((char*)respdu,respdu->uiPDULen);
                free(respdu);
                respdu=NULL;
            }else if(ret==0)//好友存在
            {
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_RESPOND;
                strcpy(respdu->caData,EXISTED_FRIEND);
                write((char*)respdu,respdu->uiPDULen);
                free(respdu);
                respdu=NULL;
            }else if(ret==1)
            {
                MyTcpServer::getInstance().resend(caPername,pdu);//转发
            }else if(ret==2)//好友下线
            {
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_RESPOND;
                strcpy(respdu->caData,ADD_FRIEND_OFFLINE);
                write((char*)respdu,respdu->uiPDULen);
                free(respdu);
                respdu=NULL;
            }else if(ret==3)//好友不存在
            {
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_RESPOND;
                strcpy(respdu->caData,ADD_FRIEND_NO_EXIST);
                write((char*)respdu,respdu->uiPDULen);
                free(respdu);
                respdu=NULL;
            }
            break;
        }

        case ENUM_MSG_TYPE_FLUSH_FRIEND_REQUEST://刷新好友请求
        {
            char caName[32]={'\0'};
            strncpy(caName,pdu->caData,32);
            QStringList ret=OpeDB::getInstance().handleFlushFriend(caName);
            uint uiMsgLen=ret.size()*32;
            PDU* respdu=mkPDU(uiMsgLen);
            respdu->uiMsgType=ENUM_MSG_TYPE_FLUSH_FRIEND_RESPOND;
            for(int i=0;i<ret.size();i++)
            {
                memcpy((char*)(respdu->caMsg)+i*32
                       ,ret.at(i).toStdString().c_str()
                       ,ret.at(i).size());
            }
            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_DELETE_FRIEND_REQUEST://删除好友请求
        {
            char caSelfName[32]={'\0'};
            char caFriendName[32]={'\0'};
            strncpy(caSelfName,pdu->caData,32);
            strncpy(caFriendName,pdu->caData+32,32);
            OpeDB::getInstance().handleDelFriend(caSelfName,caFriendName);
            PDU* respdu=mkPDU(0);
            respdu->uiMsgType=ENUM_MSG_TYPE_DELETE_FRIEND_RESPOND;
            strcpy(respdu->caData,DEL_FRIEND_OK);
            write((char*)respdu,respdu->uiPDULen);//发送给客户端
            free(respdu);
            respdu=NULL;
            MyTcpServer::getInstance().resend(caFriendName,pdu);//发送给被删除的好友
            break;
        }

        case ENUM_MSG_TYPE_PRIVATE_CHAT_REQUEST://私聊用户请求
        {
            char caPerName[32]={'\0'};
            memcpy(caPerName,pdu->caData+32,32);
            //qDebug()<<caPerName;

            MyTcpServer::getInstance().resend(caPerName,pdu);//发送给被私聊的好友

            break;
        }

        case ENUM_MSG_TYPE_ADD_FRIEND_AGREE://同意添加好友
        {
            char caPerName[32]={'\0'};
            char caName[32]={'\0'};
            strncpy(caPerName,pdu->caData,32);
            strncpy(caName,pdu->caData+32,32);
            OpeDB::getInstance().agreeAddFriend(caPerName,caName);
            break;
        }

        case ENUM_MSG_TYPE_ADD_FRIEND_REFUSE://拒绝添加好友
        {
            //拒绝添加好友就不做任何操作
            break;
        }

        case ENUM_MSG_TYPE_GROUP_CHAT_REQUEST://群发信息请求
        {
            char caName[32]={'\0'};
            strncpy(caName,pdu->caData,32);
            QStringList onlineFriend=OpeDB::getInstance().handleFlushFriend(caName);
            QString temp;
            for(int i=0;i<onlineFriend.size();i++)
            {
                temp=onlineFriend.at(i);
                MyTcpServer::getInstance().resend(temp.toStdString().c_str(),pdu);
            }
            break;
        }

        case ENUM_MSG_TYPE_CREATE_DIR_REQUEST://创建文件请求
        {
            QDir dir;
            QString strCurPath=QString("%1").arg((char*)(pdu->caMsg));
            qDebug()<<strCurPath;
            bool ret=dir.exists(strCurPath);
            PDU*respdu=NULL;
            if(ret)  //当前目录存在
            {
                char caNewDir[32]={'\0'};
                memcpy(caNewDir,pdu->caData+32,32);
                QString strNewPath=strCurPath+"/"+caNewDir;
                qDebug()<<strNewPath;
                ret=dir.exists(strNewPath);//判断重名文件夹
                qDebug()<<"----->"<<ret;
                if(ret)//文件夹重名
                {
                    respdu=mkPDU(0);
                    respdu->uiMsgType=ENUM_MSG_TYPE_CREATE_DIR_RESPOND;
                    strcpy(respdu->caData,FILE_NAME_EXIST);

                }else//文件夹没有重名
                {
                    dir.mkdir(strNewPath);
                    respdu=mkPDU(0);
                    respdu->uiMsgType=ENUM_MSG_TYPE_CREATE_DIR_RESPOND;
                    strcpy(respdu->caData,CREATE_DIR_OK);
                }


            }else   //当前目录不存在
            {
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_CREATE_DIR_RESPOND;
                strcpy(respdu->caData,DIR_NO_EXIST);
            }
            write((char*)respdu,respdu->uiPDULen);//发送给客户端
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_FLUSH_FILE_REQUEST://刷新文件夹请求
        {
            char* pCurPath=new char[pdu->uiPDULen];
            memcpy(pCurPath,pdu->caMsg,pdu->uiMsgLen);

            QDir dir(pCurPath);
            QFileInfoList fileInfoList=dir.entryInfoList();
            int iFileCount=fileInfoList.size();
            PDU* respdu=mkPDU(sizeof(FileInfo)*iFileCount);
            respdu->uiMsgType=ENUM_MSG_TYPE_FLUSH_FILE_RESPOND;
            FileInfo* pFileInfo=NULL;
            QString strFileName;
            for(int i=0;i<fileInfoList.size();i++)
            {
                pFileInfo=(FileInfo*)(respdu->caMsg)+i;;
                strFileName=fileInfoList[i].fileName();
                memcpy(pFileInfo->caFileName,strFileName.toStdString().c_str(),strFileName.size());
                if(fileInfoList[i].isDir())
                {
                    pFileInfo->iFileType=0;
                }else if(fileInfoList[i].isFile())
                {
                    pFileInfo->iFileType=1;
                }
            }
            write((char*)respdu,respdu->uiPDULen);//发送给客户端
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_DEL_DIR_REQUEST://删除目录请求
        {
            char caName[32]={'\0'};
            strcpy(caName,pdu->caData);
            char *pPath=new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);
            QString strPath=QString("%1/%2").arg(pPath).arg(caName);
            //qDebug()<<strPath;

            QFileInfo fileInfo(strPath);

            bool ret=false;
            if(fileInfo.isDir())//文件夹
            {
                QDir dir;
                dir.setPath(strPath);
                ret=dir.removeRecursively();
            }else if(fileInfo.isFile())//常规文件
            {
                ret=false;
            }

            PDU* respdu=NULL;

            if(ret)
            {
                respdu=mkPDU(strlen(DEL_DIR_OK)+1);
                respdu->uiMsgType=ENUM_MSG_TYPE_DEL_DIR_RESPOND;
                memcpy(respdu->caData,DEL_DIR_OK,strlen(DEL_DIR_OK));
            }else
            {
                respdu=mkPDU(strlen(DEL_DIR_FAILED)+1);
                respdu->uiMsgType=ENUM_MSG_TYPE_DEL_DIR_RESPOND;
                memcpy(respdu->caData,DEL_DIR_FAILED,strlen(DEL_DIR_FAILED));
            }
            write((char*)respdu,respdu->uiPDULen);//发送给客户端
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_RENAME_FILE_REQUEST://重命名文件夹
        {
            char caOldName[32]={'\0'};
            char caNewName[32]={'\0'};
            strncpy(caOldName,pdu->caData,32);
            strncpy(caNewName,pdu->caData+32,32);

            char* pPath=new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);

            QString strOldPath=QString("%1/%2").arg(pPath).arg(caOldName);
            QString strNewPath=QString("%1/%2").arg(pPath).arg(caNewName);

            //        qDebug()<<strOldPath;
            //        qDebug()<<strNewPath;

            QDir dir;
            bool ret=dir.rename(strOldPath,strNewPath);
            PDU *respdu=mkPDU(0);
            respdu->uiMsgType=ENUM_MSG_TYPE_RENAME_FILE_RESPOND;

            if(ret)
            {

                strcpy(respdu->caData,RENAME_FILE_OK);
            }else
            {
                strcpy(respdu->caData,RENAME_FILE_FAILED);
            }
            write((char*)respdu,respdu->uiPDULen);//发送给客户端
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_ENTER_DIR_REQUEST://进入目录
        {
            char caEnterName[32]={'\0'};
            strncpy(caEnterName,pdu->caData,32);

            char* pPath=new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);
            QString strPath=QString("%1/%2").arg(pPath).arg(caEnterName);

            QFileInfo fileInfo(strPath);
            PDU* respdu=NULL;

            if(fileInfo.isDir())
            {
                QDir dir(strPath);
                QFileInfoList fileInfoList=dir.entryInfoList();
                int iFileCount=fileInfoList.size();
                respdu=mkPDU(sizeof(FileInfo)*iFileCount);
                respdu->uiMsgType=ENUM_MSG_TYPE_FLUSH_FILE_RESPOND;
                FileInfo* pFileInfo=NULL;
                QString strFileName;
                for(int i=0;i<fileInfoList.size();i++)
                {
                    pFileInfo=(FileInfo*)(respdu->caMsg)+i;;
                    strFileName=fileInfoList[i].fileName();
                    memcpy(pFileInfo->caFileName,strFileName.toStdString().c_str(),strFileName.size());
                    if(fileInfoList[i].isDir())
                    {
                        pFileInfo->iFileType=0;
                    }else if(fileInfoList[i].isFile())
                    {
                        pFileInfo->iFileType=1;
                    }
                }
                write((char*)respdu,respdu->uiPDULen);//发送给客户端
                free(respdu);
                respdu=NULL;


            }else if(fileInfo.isFile())
            {
                respdu=mkPDU(0);
                respdu->uiMsgType=ENUM_MSG_TYPE_ENTER_DIR_RESPOND;
                strcpy(respdu->caData,ENTER_DIR_FAILED);
                write((char*)respdu,respdu->uiPDULen);//发送给客户端
                free(respdu);
                respdu=NULL;
            }
            break;
        }

        case ENUM_MSG_TYPE_UPLOAD_FILE_REQUEST://上传文件请求
        {
            char caFileName[32]={'\0'};
            qint64 fileSize=0;
            sscanf(pdu->caData,"%s %lld",caFileName,&fileSize);
            char* pPath=new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);
            QString strPath=QString("%1/%2").arg(pPath).arg(caFileName);

            delete[]pPath;
            pPath=NULL;

            m_file.setFileName(strPath);
            if(m_file.open(QIODevice::WriteOnly))//以只写的方式打开文件，若文件不存在，则会自动创建文件
            {
                m_bUpload=true;
                m_iTotal=fileSize;
                m_iRecved=0;
            }
            break;
        }

        case ENUM_MSG_TYPE_DEL_FILE_REQUEST://删除文件请求
        {

            char caName[32]={'\0'};
            strcpy(caName,pdu->caData);
            char *pPath=new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);
            QString strPath=QString("%1/%2").arg(pPath).arg(caName);
            QFileInfo fileInfo(strPath);

            bool ret=false;
            if(fileInfo.isDir())//文件夹
            {
                ret=false;
            }else if(fileInfo.isFile())//常规文件
            {
                QDir dir;
                ret=dir.remove(strPath);
            }

            PDU* respdu=NULL;

            if(ret)
            {
                respdu=mkPDU(strlen(DEL_FILE_OK)+1);
                respdu->uiMsgType=ENUM_MSG_TYPE_DEL_FILE_RESPOND;
                memcpy(respdu->caData,DEL_FILE_OK,strlen(DEL_FILE_OK));
            }else
            {
                respdu=mkPDU(strlen(DEL_FILE_FAILED)+1);
                respdu->uiMsgType=ENUM_MSG_TYPE_DEL_FILE_RESPOND;
                memcpy(respdu->caData,DEL_FILE_FAILED,strlen(DEL_FILE_FAILED));
            }
            write((char*)respdu,respdu->uiPDULen);//发送给客户端
            free(respdu);
            respdu=NULL;
            break;
        }

        case ENUM_MSG_TYPE_DOWNLOAD_FILE_REQUEST://下载文件请求
        {
            char caFileName[32]={'\0'};
            strcpy(caFileName,pdu->caData);
            char* pPath=new char[pdu->uiMsgLen];
            memcpy(pPath,pdu->caMsg,pdu->uiMsgLen);
            QString strPath=QString("%1/%2").arg(pPath).arg(caFileName);

            delete []pPath;
            pPath=NULL;

            QFileInfo fileInfo(strPath);
            qint64 fileSize=fileInfo.size();

            PDU* respdu=mkPDU(0);
            respdu->uiMsgType=ENUM_MSG_TYPE_DOWNLOAD_FILE_RESPOND;
            sprintf(respdu->caData,"%s %lld",caFileName,fileSize);

            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;

            m_file.setFileName(strPath);

            m_file.open(QIODevice::ReadOnly);

            m_pTimer->start(1000);

            break;
        }

        case ENUM_MSG_TYPE_SHARE_FILE_REQUEST://分享文件请求
        {
            char caSendName[32]={'\0'};
            int num=0;
            sscanf(pdu->caData,"%s%d",caSendName,&num);
            int size=num*32;

            PDU* respdu=mkPDU(pdu->uiMsgLen-size);
            respdu->uiMsgType=ENUM_MSG_TYPE_SHARE_FILE_NOTE;
            strcpy(respdu->caData,caSendName);
            memcpy((char*)(respdu->caMsg),(char*)(pdu->caMsg)+size,pdu->uiMsgLen-size);
            char caRecvName[32]={'\0'};
            for(int i=0;i<num;i++)
            {
                memcpy(caRecvName,(char*)(pdu->caMsg)+i*32,32);

                MyTcpServer::getInstance().resend(caRecvName,respdu);

            }
            free(respdu);
            respdu=NULL;

            respdu=mkPDU(0);
            respdu->uiMsgType=ENUM_MSG_TYPE_SHARE_FILE_RESPOND;
            strcpy(respdu->caData,"share file ok");
            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;


            break;
        }

        case ENUM_MSG_TYPE_SHARE_FILE_NOTE_RESPOND:
        {
            QString strRecvPath=QString("./%1").arg(pdu->caData);
            QString strShareFilePath=QString("%1").arg((char*)(pdu->caMsg));
            int index=strShareFilePath.lastIndexOf('/');
            QString strFileName=strShareFilePath.right(strShareFilePath.size()-index-1);
            strRecvPath=strRecvPath+'/'+strFileName;

            QFileInfo fileInfo(strShareFilePath);
            if(fileInfo.isFile())
            {
                QFile::copy(strShareFilePath,strRecvPath);


            }else if(fileInfo.isDir())
            {
                copyDir(strShareFilePath,strRecvPath);
            }

            break;
        }

        case ENUM_MSG_TYPE_MOVE_FILE_REQUEST://移动文件请求
        {
            char caFileName[32]={'\0'};
            int srcLen=0;
            int destLen=0;
            sscanf(pdu->caData,"%d%d%s",&srcLen,&destLen,caFileName);

            char *pSrcPath=new char[srcLen+1];
            char *pDestPath=new char[destLen+1+32];
            memset(pSrcPath,'\0',srcLen+1);
            memset(pDestPath,'\0',destLen+1+32);

            memcpy(pSrcPath,pdu->caMsg,srcLen);
            memcpy(pDestPath,(char*)(pdu->caMsg)+(srcLen+1),destLen);

            PDU*respdu=mkPDU(0);
            respdu->uiMsgType=ENUM_MSG_TYPE_MOVE_FILE_RESPOND;

            QFileInfo fileInfo(pDestPath);
            if(fileInfo.isDir())
            {
                strcat(pDestPath,"/");
                strcat(pDestPath,caFileName);

                bool ret=QFile::rename(pSrcPath,pDestPath);
                if(ret)
                {

                    strcpy(respdu->caData,MOVE_FILE_OK);
                }else
                {

                    strcpy(respdu->caData,COMMON_ERROR);
                }

            }else if(fileInfo.isFile())
            {

                strcpy(respdu->caData,MOVE_FILE_FAILED);
            }

            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;
            break;
        }

        default:
            break;
        }
        free(pdu);
        pdu=NULL;
    }else
    {


        PDU*respdu=NULL;
        respdu=mkPDU(0);
        respdu->uiMsgType=ENUM_MSG_TYPE_UPLOAD_FILE_RESPOND;
        QByteArray buff=readAll();
        m_file.write(buff);
        m_iRecved+=buff.size();
        if(m_iTotal==m_iRecved)
        {
            m_file.close();
            m_bUpload=false;

            strcpy(respdu->caData,UPLOAD_FILE_OK);
            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;
        }else if(m_iTotal<m_iRecved)
        {
            m_file.close();
            m_bUpload=false;

            strcpy(respdu->caData,UPLOAD_FILE_FAILED);
            write((char*)respdu,respdu->uiPDULen);
            free(respdu);
            respdu=NULL;
        }

    }
}

void MyTcpSocket::clientOffline()
{
    OpeDB::getInstance().handleOffline(m_strName.toStdString().c_str());
    emit offline(this);
}

void MyTcpSocket::sendFileToClient()
{
    m_pTimer->stop();
    char *pData=new char[4096];
    qint64 ret=0;
    while(true)
    {
        ret=m_file.read(pData,4096);

        if(ret>0 && ret<=4096)
        {
            write(pData,ret);
        }else if(ret==0)
        {
            m_file.close();
            break;
        }else if(ret<0)
        {
            qDebug()<<"发送文件内容给客户端过程失败";
            m_file.close();
            break;
        }
    }
    delete []pData;
    pData=NULL;
}


