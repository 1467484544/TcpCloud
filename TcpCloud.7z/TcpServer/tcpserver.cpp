#include "tcpserver.h"
#include "ui_tcpserver.h"

#include"mytcpserver.h"

#include <QByteArray>
#include <QFile>
#include <QMessageBox>
#include<QDebug>

TcpServer::TcpServer(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::TcpServer)
{
    ui->setupUi(this);

    //加载文件
    loadConfig();

    //服务器监听
    MyTcpServer::getInstance().listen(QHostAddress(m_strIp),m_usPort);
}

TcpServer::~TcpServer()
{
    delete ui;
}

void TcpServer::loadConfig()
{
    QFile file(":/server.config");
    if(file.open(QIODevice::ReadOnly))//QIODevice作用域下的只读打开，返回类型bool值
    {
        QByteArray baData=file.readAll();//读取数据是字节类型
        QString strData=(QString)(baData);
        file.close();
        strData.replace("\r\n"," ");
        QStringList strList=strData.split(" ");
        m_strIp=strList.at(0);
        m_usPort=strList.at(1).toUShort();
    }else
    {
        QMessageBox::critical(this,"打开文件","打开文件失败!");
    }
}

