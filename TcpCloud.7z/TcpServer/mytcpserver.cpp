#include "mytcpserver.h"
#include<QDebug>


MyTcpServer::MyTcpServer()
{

}

MyTcpServer &MyTcpServer::getInstance()
{
    static MyTcpServer instance;
    return instance;
}


//当有新客户端连接时，会创建一个自定义的 MyTcpSocket 对象
//将新创建的套接字与客户端连接的socketDescriptor关联
//将这个套接字添加到服务器维护的套接字列表中
//建立信号槽连接，以便在客户端断开连接时能正确清理资源
void MyTcpServer::incomingConnection(qintptr socketDescriptor)
{
    qDebug()<<"新的客户端连接！";
    MyTcpSocket* pTcpSocket=new MyTcpSocket;
    pTcpSocket->setSocketDescriptor(socketDescriptor);//重新关联已存在的套接字描述符
    m_tcpSocketList.append(pTcpSocket);
    connect(pTcpSocket,SIGNAL(offline(MyTcpSocket*)),this,SLOT(deleteSocket(MyTcpSocket*)));
}

void MyTcpServer::resend(const char *pername, PDU *pdu)
{
    if(pername==NULL||pdu==NULL)
    {
        return;
    }
    QString strName=pername;

    for(int i=0;i<m_tcpSocketList.size();i++)
    {
        if(m_tcpSocketList.at(i)->getName()==strName)
        {
            m_tcpSocketList.at(i)->write((char*)pdu,pdu->uiPDULen);
            break;
        }
    }

}

void MyTcpServer::deleteSocket(MyTcpSocket *mysocket)
{
    for(QList<MyTcpSocket*>::iterator it=m_tcpSocketList.begin();
        it!=m_tcpSocketList.end();it++)
    {
        if(*it==mysocket)
        {
            //delete *it;
            (*it)->deleteLater();
            *it=NULL;
            m_tcpSocketList.erase(it);
            break;
        }
    }

    for(int i=0;i<m_tcpSocketList.size();i++)
    {
        qDebug()<<m_tcpSocketList.at(i)->getName();
    }
}
